package com.example.admin.baking;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.baking.dummy.DummyContent;
import com.example.admin.baking.model.Ingredient;
import com.example.admin.baking.model.Step;

import java.util.ArrayList;


public class ItemListActivity extends AppCompatActivity {


    private boolean mTwoPane;
    ArrayList<? extends Step> stepArrayList;
    ArrayList<? extends Ingredient> ingredientArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        String title=getIntent().getStringExtra("title");
        getSupportActionBar().setTitle(title);

        stepArrayList=new ArrayList<>();
        ingredientArrayList=new ArrayList<>();

       stepArrayList=getIntent().getParcelableArrayListExtra("stepsList");
        ingredientArrayList=getIntent().getParcelableArrayListExtra("ingredientsList");

        Toast.makeText(this, ""+title, Toast.LENGTH_SHORT).show();


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StringBuilder stringBuilder=new StringBuilder();
                StringBuilder str=new StringBuilder();
                String t,k=null;
                SharedPreferences sharedPreferences=getSharedPreferences("file",MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();


                Intent intent=new Intent(ItemListActivity.this,IngredientsActivity.class);

                for(int i=0;i<ingredientArrayList.size();i++){
                    String quantity=ingredientArrayList.get(i).getQuantity();
                    String measure=ingredientArrayList.get(i).getMeasure();
                    t="Measure:"+quantity.concat(" ").concat(measure);
                    stringBuilder.append("Ingredient:"+ingredientArrayList.get(i).getIngredient()+"\n"+t+"\n");
                    str.append(ingredientArrayList.get(i).getIngredient()+" "+t+"\n");

                }
                editor.putString("key",str.toString());
                editor.commit();


                Intent i = new Intent(ItemListActivity.this, BakingWidget.class);
                i.setAction("android.appwidget.action.APPWIDGET_UPDATE");
                int widget[] = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), BakingWidget.class));
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, widget);
                sendBroadcast(i);
                intent.putExtra("measure",stringBuilder.toString());
                startActivity(intent);
            }
        });

        if (findViewById(R.id.item_detail_container) != null) {


            mTwoPane = true;
        }

        View recyclerView = findViewById(R.id.item_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);
    }

    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(this, (ArrayList<Step>) stepArrayList, mTwoPane));
    }

    public static class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final ItemListActivity mParentActivity;

        ArrayList<Step> stepArrayList;
        private final boolean mTwoPane;
        private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DummyContent.DummyItem item = (DummyContent.DummyItem) view.getTag();
                if (mTwoPane) {
                    Bundle arguments = new Bundle();
                    arguments.putString(ItemDetailFragment.ARG_ITEM_ID, item.id);
                    ItemDetailFragment fragment = new ItemDetailFragment();
                    fragment.setArguments(arguments);
                    mParentActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.item_detail_container, fragment)
                            .commit();
                } else {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, ItemDetailActivity.class);
                    intent.putExtra(ItemDetailFragment.ARG_ITEM_ID, item.id);

                    context.startActivity(intent);
                }
            }
        };

        SimpleItemRecyclerViewAdapter(ItemListActivity parent,
                                      ArrayList<Step> items,
                                      boolean twoPane) {
            this.stepArrayList = items;
            mParentActivity = parent;
            mTwoPane = twoPane;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mIdView.setText(""+stepArrayList.get(position).getId());
            holder.mContentView.setText(stepArrayList.get(position).getShortDescription());



        }

        @Override
        public int getItemCount() {
            return stepArrayList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            final TextView mIdView;
            final TextView mContentView;

            ViewHolder(View view) {
                super(view);
                mIdView = (TextView) view.findViewById(R.id.id_text);
                mContentView = (TextView) view.findViewById(R.id.content);
                view.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                int position=getAdapterPosition();
                if(mTwoPane){
                    String videourl=stepArrayList.get(position).getVideoURL();
                    String thumblineurl=stepArrayList.get(position).getThumbnailURL();
                    String discription=stepArrayList.get(position).getDescription();
                    Bundle arguments = new Bundle();
                    arguments.putString("v",videourl);
                    arguments.putString("t",thumblineurl);
                    arguments.putString("d",discription);
                    ItemDetailFragment fragment = new ItemDetailFragment();
                    fragment.setArguments(arguments);
                    mParentActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.item_detail_container, fragment)
                            .commit();

                }
                else {
                    String videourl=stepArrayList.get(position).getVideoURL();
                    String thumblineurl=stepArrayList.get(position).getThumbnailURL();
                    String discription=stepArrayList.get(position).getDescription();
                    Intent intent=new Intent(mParentActivity,ItemDetailActivity.class);
                    intent.putExtra("posit",position);
                    intent.putParcelableArrayListExtra("arrposition", (ArrayList<? extends Parcelable>) stepArrayList);
                    intent.putExtra("v",videourl);
                    intent.putExtra("t",thumblineurl);
                    intent.putExtra("d",discription);
                    mParentActivity.startActivity(intent);

                }


            }
        }
    }
}
