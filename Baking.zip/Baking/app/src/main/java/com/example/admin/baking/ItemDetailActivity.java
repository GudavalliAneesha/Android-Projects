package com.example.admin.baking;

import android.content.Intent;
import android.os.Bundle;

import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.admin.baking.model.Step;

import java.util.ArrayList;



public class ItemDetailActivity extends AppCompatActivity {
    String videourl,thumblineurl,discription;
    int posi;
    ArrayList<? extends Step> steps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.detail_toolbar);
        setSupportActionBar(toolbar);
        videourl=getIntent().getStringExtra("v");
        thumblineurl=getIntent().getStringExtra("t");
        discription=getIntent().getStringExtra("d");
        posi=getIntent().getIntExtra("posit",0);
        steps=getIntent().getParcelableArrayListExtra("arrposition");

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }


        if (savedInstanceState == null) {


            Bundle arguments = new Bundle();


            arguments.putString("v",videourl);
            arguments.putString("t",thumblineurl);
            arguments.putString("d",discription);
            ItemDetailFragment fragment = new ItemDetailFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.item_detail_container, fragment)
                    .commit();

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {


            NavUtils.navigateUpTo(this, new Intent(this, ItemListActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void previou_video(View view) {
        posi--;
        if(posi==steps.size()-1){
            Toast.makeText(this, "steps", Toast.LENGTH_SHORT).show();


        }
        else{
            videourl=steps.get(posi).getVideoURL();
            thumblineurl=steps.get(posi).getThumbnailURL();
            discription=steps.get(posi).getDescription();
            Bundle bundle=new Bundle();
            bundle.putString("v",videourl);
            bundle.putString("t",thumblineurl);
            bundle.putString("d",discription);
            ItemDetailFragment itemDetailFragment=new ItemDetailFragment();
            itemDetailFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.item_detail_container,itemDetailFragment).commit();
        }
    }

    public void next_video(View view) {
        if(posi==steps.size()-1) {
            Toast.makeText(this, "next", Toast.LENGTH_SHORT).show();
        }
        else {
            posi++;
            videourl=steps.get(posi).getVideoURL();
            thumblineurl=steps.get(posi).getThumbnailURL();
            discription=steps.get(posi).getDescription();
            Bundle bundle=new Bundle();
            bundle.putString("v",videourl);
            bundle.putString("t",thumblineurl);
            bundle.putString("d",discription);
            ItemDetailFragment itemDetailFragment=new ItemDetailFragment();
            itemDetailFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.item_detail_container,itemDetailFragment).commit();

        }

    }
}
