package com.example.admin.baking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.baking.model.Recipe;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RequestQueue requestQueue;
    List<Recipe> receipeArrayList;
    RecyclerView recyclerView;
    List<String> images;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        receipeArrayList=new ArrayList<>();

        images=new ArrayList<>();
        images.add(getResources().getString(R.string.nutellaPie));
        images.add(getResources().getString(R.string.brownies));
        images.add(getResources().getString(R.string.yellowCake));
        images.add(getResources().getString(R.string.cheeseCake));

        requestQueue= Volley.newRequestQueue(this);
        parseJsonData();
        recyclerView=findViewById(R.id.bakingrecycler_id);

    }
    public void parseJsonData()
    {
        final String baking_url=getString(R.string.bakingAppUrl);
        StringRequest stringRequest=new StringRequest(Request.Method.GET, baking_url, new Response.Listener<String>()
        {
            @Override
            public void onResponse(String response)
            {
                GsonBuilder builder=new GsonBuilder();
                Gson mgson=builder.create();
                receipeArrayList= Arrays.asList(mgson.fromJson(response,Recipe[].class));
                Toast.makeText(MainActivity.this, ""+receipeArrayList.size(), Toast.LENGTH_SHORT).show();
                Bakingadapter bakingadapter=new Bakingadapter(MainActivity.this,receipeArrayList,images);
                recyclerView.setAdapter(bakingadapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "NO Internet", Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);
    }
}
