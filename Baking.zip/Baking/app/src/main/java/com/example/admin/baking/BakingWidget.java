package com.example.admin.baking;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import static android.content.Context.MODE_PRIVATE;


public class BakingWidget extends AppWidgetProvider {

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        SharedPreferences sharedPreferences=context.getSharedPreferences("file",MODE_PRIVATE);
        String data=sharedPreferences.getString("key","");
        CharSequence widgetText=data;


        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.baking_widget);
        views.setTextViewText(R.id.appwidget_text, widgetText);
        Intent i=new Intent(context,MainActivity.class);
        sharedPreferences.edit().clear();
        PendingIntent pIntent=PendingIntent.getActivity(context,0,i,0);
        views.setOnClickPendingIntent(R.id.appwidget_text,pIntent);

               appWidgetManager.updateAppWidget(appWidgetId, views);

    }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {

        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {

    }

    @Override
    public void onDisabled(Context context) {

    }
}

