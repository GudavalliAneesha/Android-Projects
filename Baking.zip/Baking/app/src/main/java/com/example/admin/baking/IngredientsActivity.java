package com.example.admin.baking;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.admin.baking.model.Ingredient;

import java.util.ArrayList;

public class IngredientsActivity extends AppCompatActivity {
    TextView tv1;
    ArrayList<Ingredient> ingredientArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredients);
        tv1=findViewById(R.id.ingrident_id);
        String measure=getIntent().getStringExtra("measure");
        tv1.setText(measure);

    }
}
