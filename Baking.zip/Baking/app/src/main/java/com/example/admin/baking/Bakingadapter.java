package com.example.admin.baking;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.baking.model.Recipe;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Bakingadapter extends RecyclerView.Adapter<Bakingadapter.BakingViewHolder> {
    Context context;
    List<Recipe> arrayList;
    List<String> images;

    public Bakingadapter(MainActivity listener, List<Recipe> receipeArrayList, List<String> image) {

        this.context = listener;
        arrayList = receipeArrayList;
        images = image;
    }

    @Override
    public Bakingadapter.BakingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.baking_row, parent, false);
        BakingViewHolder baking = new BakingViewHolder(view);
        return baking;
    }

    @Override
    public void onBindViewHolder(Bakingadapter.BakingViewHolder holder, int position) {
        holder.textView.setText(arrayList.get(position).getName());



        Picasso.with(context).load(images.get(position)).into(holder.imageView);


    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class BakingViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView;
       ImageView imageView;

        public BakingViewHolder(View itemView) {
            super(itemView);
           imageView = itemView.findViewById(R.id.image_id);
            textView = itemView.findViewById(R.id.recipiename);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {

                Intent intent=new Intent(context,ItemListActivity.class);
                intent.putParcelableArrayListExtra("stepsList", (ArrayList<? extends Parcelable>) arrayList.get(position).getSteps());
                intent.putParcelableArrayListExtra("ingredientsList", (ArrayList<? extends Parcelable>) arrayList.get(position).getIngredients());
                intent.putExtra("title",arrayList.get(position).getName());
                context.startActivity(intent);
            }
        }
    }
}