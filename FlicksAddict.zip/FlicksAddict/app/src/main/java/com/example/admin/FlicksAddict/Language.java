package com.example.admin.FlicksAddict;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Loader;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class Language extends AsyncTask<String,Void,String> {
    ArrayList<Movie> marrayList;

    MainActivity ct;
    String type;
    public Language(MainActivity mainActivity, String options) {
        ct=mainActivity;
        type=options;
        Toast.makeText(mainActivity, type, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected String doInBackground(String... strings) {
        String link="https://api.themoviedb.org/3/discover/movie?api_key=28dc92edb81b1563c1c98330f9e0776c&with_original_language="+type;
        try {
            URL ur=new URL(link);
            HttpsURLConnection httpsURLConnection= (HttpsURLConnection) ur.openConnection();
            httpsURLConnection.setRequestMethod("GET");
            httpsURLConnection.connect();
            InputStream inputStream=httpsURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));

            StringBuilder stringBuilder=new StringBuilder();
            String line="";
            while((line=bufferedReader.readLine())!=null){
                stringBuilder.append(line+"\n");

            }
            return stringBuilder.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }


        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        marrayList=new ArrayList<>();
        //Toast.makeText(ct, ""+s, Toast.LENGTH_SHORT).show();

        try {
            JSONObject jsonObject=new JSONObject(s);
            JSONArray jsonArray=jsonObject.getJSONArray("results");
            for(int i=0;i<jsonArray.length();i++){
                JSONObject jsonObject1=jsonArray.getJSONObject(i);
                String var_id=jsonObject1.getString("id");
                String var_vote=jsonObject1.getString("vote_average");
                String var_title=jsonObject1.getString("title");
                String var_poster=ct.myinglink+jsonObject1.getString("poster_path");
                String var_overview=jsonObject1.getString("overview");
                String var_Release_date=jsonObject1.getString("release_date");
                Movie movie=new Movie(var_id,var_vote,var_title,var_poster,var_overview,var_Release_date);
                marrayList.add(movie);
            }
            MyAdapter adapter=new MyAdapter(ct,marrayList);
            ct. recyclerView.setAdapter(adapter);
        }

        catch (Exception e) {
            e.printStackTrace();
        }


    }
}
