package com.example.admin.FlicksAddict;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.admin.FlicksAddict.roomdatabase.Myentity;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Favourite extends RecyclerView.Adapter<Favourite.FavHolder> {
    List<Myentity> entity;
    MainActivity ct;

    public Favourite(List<Myentity> myentities, MainActivity mainActivity) {
        entity=myentities;
        ct=mainActivity;
    }

    @Override
    public Favourite.FavHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(ct).inflate(R.layout.myresource,parent,false);
        return new FavHolder(view);

    }

    @Override
    public void onBindViewHolder(Favourite.FavHolder holder, int position) {
        Picasso.with(ct).load(entity.get(position).getImg()).into(holder.imageView);


    }

    @Override
    public int getItemCount() {
        return entity.size();
    }

    public class FavHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        public FavHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.image_id);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();
            Intent intent=new Intent(ct,DetailsActivity.class);
            intent.putExtra("image",entity.get(position).getImg());
            intent.putExtra("tit",entity.get(position).getTitle());
            intent.putExtra("rate",entity.get(position).getRating());
            intent.putExtra("rel",entity.get(position).getReleasedate());
            intent.putExtra("over",entity.get(position).getDescription());
            intent.putExtra("key",entity.get(position).getId());

            ct.startActivity(intent);

        }
    }
}
