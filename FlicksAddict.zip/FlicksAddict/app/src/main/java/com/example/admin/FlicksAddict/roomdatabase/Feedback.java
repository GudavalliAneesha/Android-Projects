package com.example.admin.FlicksAddict.roomdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.FlicksAddict.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Feedback extends AppCompatActivity {
    EditText ed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        ed = findViewById(R.id.feedid);
    }

    public void dofeedback(View view) {

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");
        String ding = myRef.push().getKey();
        if (TextUtils.isEmpty(ed.getText().toString())) {
            myRef.child(ding).setValue(ed.getText().toString());
            Toast.makeText(this, "Please enter feedback", Toast.LENGTH_SHORT).show();
        } else {
            myRef.child(ding).setValue(ed.getText().toString());
            Toast.makeText(this, "feedback sent successfully", Toast.LENGTH_SHORT).show();
        }
    }
}
