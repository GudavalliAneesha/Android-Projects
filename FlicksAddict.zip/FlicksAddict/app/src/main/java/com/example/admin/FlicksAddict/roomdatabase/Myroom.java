package com.example.admin.FlicksAddict.roomdatabase;


import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Myentity.class},version = 1,exportSchema = false)
public abstract class Myroom extends RoomDatabase {
    public abstract Mydao mydao();
    private static Myroom INSTANCE;

    public static Myroom getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (Myroom.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            Myroom.class, "roomdb")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}


