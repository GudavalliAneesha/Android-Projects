package com.example.admin.FlicksAddict;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.admin.FlicksAddict.roomdatabase.Feedback;
import com.example.admin.FlicksAddict.roomdatabase.Myentity;
import com.example.admin.FlicksAddict.roomdatabase.Viewmodel;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity{
    RecyclerView recyclerView;
    ArrayList<Movie> arrayList;
    Viewmodel viewmodel;
    String myinglink="https://image.tmdb.org/t/p/w500";
    String options=null;
    private FirebaseAuth mAuth;

    ConnectivityManager connectivityManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView_id);
        mAuth = FirebaseAuth.getInstance();
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(connectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(connectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
        }

        else {
            Toast.makeText(this, "No Internet", Toast.LENGTH_SHORT).show();
        }




        viewmodel= ViewModelProviders.of(this).get(Viewmodel.class);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));

        if (savedInstanceState != null) {
            options = savedInstanceState.getString("save");
            Toast.makeText(this,options, Toast.LENGTH_SHORT).show();
            if(options.equalsIgnoreCase("top_rated")){
                Log.i("options",options);
                Bundle b = new Bundle();
                b.putString("op", options);

                Myasc myasc=new Myasc(this,b);
                myasc.execute();
            }
            else if (options.equalsIgnoreCase("popular")){
                options = "popular";
                Log.i("options",options);
                Bundle b = new Bundle();
                b.putString("op", options);

                Myasc myasc=new Myasc(this,b);
                myasc.execute();
            }
            else if (options.equalsIgnoreCase("addfav")){
                myFavoriteMovies();
            }


        } else {
            options = "popular";
            Log.i("options",options);
            Bundle b = new Bundle();
            b.putString("op", options);

            Myasc myasc=new Myasc(this,b);
            myasc.execute();


        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.popular_id:
                options="popular";
                Bundle bundle1=new Bundle();
                bundle1.putString("op",options);

                Myasc myasc=new Myasc(this,bundle1);
                myasc.execute();
                break;
            case R.id.rated_id:
                options="top_rated";
                Bundle bundle=new Bundle();
                bundle.putString("op",options);

                Myasc myasc1=new Myasc(this,bundle);
                myasc1.execute();
                break;
            case R.id.favourite_id:
                myFavoriteMovies();
                options="addfav";
                break;
            case R.id.telu_id:
                options="te";
               Language language=new Language(this,options);
               language.execute();
                //getLoaderManager().initLoader(10,null,language);
                break;
            case R.id.eng_id:
                options="en";
                Language language1=new Language(this,options);
                language1.execute();
               // getLoaderManager().initLoader(11,null,language1);

                break;
            case R.id.hindi_id:
                options="hi";
                Language language2=new Language(this,options);
                language2.execute();
               // getLoaderManager().initLoader(12,null,language2);
                break;
            case  R.id.fed_id:
                Intent i=new Intent(this, Feedback.class);
                startActivity(i);

                break;
            case R.id.logoutid:
                mAuth.signOut();
                Intent intent=new Intent(this,UserLogin.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);


    }



    private void myFavoriteMovies() {
        viewmodel.listLiveData.observe(this, new Observer<List<Myentity>>() {
            @Override
            public void onChanged(@Nullable List<Myentity> myentities) {
                Favourite favouriteAdapter=new Favourite(myentities,MainActivity.this);
                recyclerView.setAdapter(favouriteAdapter);


            }
        });
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("save",options);
    }

    private class Myasc extends AsyncTask<String,Void,String> {
        MainActivity mainActivity;
        Bundle b;
        public Myasc(MainActivity mainActivity, Bundle b) {
            this.mainActivity=mainActivity;
            this.b=b;
        }

        @Override
        protected String doInBackground(String... strings) {
            String url="https://api.themoviedb.org/3/movie/"+b.getString("op")+"?api_key=28dc92edb81b1563c1c98330f9e0776c";
            try {
                URL u=new URL(url);
                HttpsURLConnection httpsURLConnection= (HttpsURLConnection) u.openConnection();
                httpsURLConnection.setRequestMethod("GET");
                httpsURLConnection.connect();
                InputStream inputStream=httpsURLConnection.getInputStream();
                BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));

                StringBuilder stringBuilder=new StringBuilder();
                String line="";
                while((line=bufferedReader.readLine())!=null){
                    stringBuilder.append(line+"\n");

                }
                return stringBuilder.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            arrayList=new ArrayList<>();
            try {
                JSONObject jsonObject=new JSONObject(s);
                JSONArray jsonArray=jsonObject.getJSONArray("results");
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject1=jsonArray.getJSONObject(i);
                    String var_id=jsonObject1.getString("id");
                    String var_vote=jsonObject1.getString("vote_average");
                    String var_title=jsonObject1.getString("title");
                    String var_poster=myinglink+jsonObject1.getString("poster_path");
                    String var_overview=jsonObject1.getString("overview");
                    String var_Release_date=jsonObject1.getString("release_date");
                    Movie movie=new Movie(var_id,var_vote,var_title,var_poster,var_overview,var_Release_date);
                    arrayList.add(movie);
                }
                MyAdapter adapter=new MyAdapter(mainActivity,arrayList);
                recyclerView.setAdapter(adapter);
            }

            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}


