package com.example.admin.FlicksAddict;

import android.appwidget.AppWidgetManager;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.FlicksAddict.roomdatabase.Myentity;
import com.example.admin.FlicksAddict.roomdatabase.Viewmodel;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class DetailsActivity extends AppCompatActivity {
    ImageView imageView,imageView2;
    TextView title,discription,release_date,rating;
    String m;
    LikeButton likeButton;
    Viewmodel vm;
    String tw,rw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_details);
        imageView=findViewById(R.id.imageView_id);
        title=findViewById(R.id.title_id);
        discription=findViewById(R.id.discription__id);
        release_date=findViewById(R.id.relesae_date__id);
        rating=findViewById(R.id.rating_id);
        imageView2=findViewById(R.id.favourite_id);
        likeButton=findViewById(R.id.heart_button);
        m=getIntent().getStringExtra("key");
        tw=getIntent().getStringExtra("tit");
        rw=getIntent().getStringExtra("rel");
        Log.i("mid",m);
        Picasso.with(this).load(getIntent().getStringExtra("image")).into(imageView);
        title.setText(getIntent().getStringExtra("tit"));
        discription.setText(getIntent().getStringExtra("over"));
        release_date.setText(getIntent().getStringExtra("rel"));
        rating.setText(getIntent().getStringExtra("rate"));
        vm=ViewModelProviders.of(this).get(Viewmodel.class);
        Enablefav();

        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Myentity myentity=new Myentity();
                myentity.setId(m);
                myentity.setTitle(getIntent().getStringExtra("tit"));
                myentity.setDescription(getIntent().getStringExtra("over"));
                myentity.setReleasedate(getIntent().getStringExtra("rel"));
                myentity.setRating(getIntent().getStringExtra("rate"));
                myentity.setImg(getIntent().getStringExtra("image"));
                vm.insert(myentity);


            }

            @Override
            public void unLiked(LikeButton likeButton) {
                Myentity myentity=new Myentity();
                myentity.setId(m);
                myentity.setTitle(getIntent().getStringExtra("tit"));
                myentity.setDescription(getIntent().getStringExtra("over"));
                myentity.setReleasedate(getIntent().getStringExtra("rel"));
                myentity.setRating(getIntent().getStringExtra("rate"));
                myentity.setImg(getIntent().getStringExtra("image"));
               vm.delete(myentity);
            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.widgetmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       switch (item.getItemId()){
           case android.R.id.home:
               break;
           case R.id.wid:
               SharedPreferences sharedPreferences=getSharedPreferences("file",MODE_PRIVATE);
              SharedPreferences.Editor editor= sharedPreferences.edit();
               editor.putString("key",tw);
               editor.putString("key2",rw);
               editor.commit();


               Intent i = new Intent(this,FlicksAddictAppWidget.class);
               i.setAction("android.appwidget.action.APPWIDGET_UPDATE");
               int widget[] = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), FlicksAddictAppWidget.class));
               i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, widget);
               sendBroadcast(i);
               break;
       }
        return super.onOptionsItemSelected(item);
    }


    private void Enablefav() {
       vm.listLiveData.observe(this, new Observer<List<Myentity>>() {
            @Override
            public void onChanged(@Nullable List<Myentity> myentities) {
                for(int i=0;i<myentities.size();i++){
                    String myid=myentities.get(i).getId();
                    Log.i("mid",myid);
                    if(m.equalsIgnoreCase(myid)){
                        likeButton.setLiked(true);
                    }
                }
            }
        });
    }

    public void trailclick(View view) {
        Intent inte=new Intent(this,VideoActivity.class);
        inte.putExtra("key",m);
        startActivity(inte);
    }

    public void Review(View view) {
        Intent reviewintent=new Intent(this,ReviewActivity.class);
        reviewintent.putExtra("key",m);
        startActivity(reviewintent);


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }






}
