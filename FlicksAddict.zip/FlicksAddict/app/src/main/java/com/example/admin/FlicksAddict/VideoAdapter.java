package com.example.admin.FlicksAddict;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.MyHolder> {
    Context ct;
    ArrayList<Video> at;
    public VideoAdapter(VideoActivity videoActivity, ArrayList<Video> avvm) {
        ct=videoActivity;
        at=avvm;
    }

    @Override
    public VideoAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View videoview= LayoutInflater.from(ct).inflate(R.layout.video,parent,false);
        return new MyHolder(videoview);
    }

    @Override
    public void onBindViewHolder(VideoAdapter.MyHolder holder, int position) {
        holder.textlink.setText(at.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return at.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textlink;
        public MyHolder(View itemView) {
            super(itemView);
            textlink=itemView.findViewById(R.id.video_id);
            textlink.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            int posit=getAdapterPosition();
           /* Uri ui=Uri.parse("https://www.youtube.com/watch?v="+at.get(posit).getKey());
            Intent inlink=new Intent(Intent.ACTION_VIEW,ui);
            ct.startActivity(inlink);*/

           Intent i=new Intent(ct,YoutubeActivity.class);
           i.putExtra("k",at.get(posit).getKey());
           ct.startActivity(i);
        }
    }
}
