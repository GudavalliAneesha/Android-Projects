package com.example.admin.FlicksAddict;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Loader;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class VideoActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String>{
    RecyclerView recyclerView;
    String mid;
    ArrayList<Video> avvm;
    LinearLayout linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        recyclerView=findViewById(R.id.videosrec);
        linearLayout=findViewById(R.id.lv);
        mid=getIntent().getStringExtra("key");
        getLoaderManager().initLoader(1,null,this);
    }

    @Override
    public Loader<String> onCreateLoader(int i, Bundle bundle) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                onForceLoad();
            }

            @Override
            public String loadInBackground() {
                try {
                    URL url=new URL("https://api.themoviedb.org/3/movie/"+mid+"/videos?api_key=28dc92edb81b1563c1c98330f9e0776c");
                    HttpsURLConnection httpsURLConnection= (HttpsURLConnection) url.openConnection();
                    InputStream is=httpsURLConnection.getInputStream();
                    BufferedReader br =new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb=new StringBuilder();
                    String newline;
                    while((newline=br.readLine())!=null){
                        sb.append(newline);

                    }
                    return sb.toString();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String s) {
        avvm=new ArrayList<>();
        try {
            JSONObject jobject=new JSONObject(s);
            JSONArray jsonArray=jobject.getJSONArray("results");
            for(int i=0;i<=jsonArray.length();i++){
                JSONObject jsonObject1=jsonArray.getJSONObject(i);
                String key=jsonObject1.getString("key");
                String name=jsonObject1.getString("name");
                Video video=new Video(key,name);
                avvm.add(video);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (avvm.size()==0){
            Snackbar.make(linearLayout,"No videos",Snackbar.LENGTH_LONG).show();
        }
        else {
            VideoAdapter va=new VideoAdapter(this,avvm);
            recyclerView.setAdapter(va);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }


    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }
}
