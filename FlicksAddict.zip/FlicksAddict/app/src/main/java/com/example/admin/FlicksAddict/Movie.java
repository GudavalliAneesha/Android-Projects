package com.example.admin.FlicksAddict;
public class Movie {


        String var_id,var_vote,var_title,var_poster,var_overview,var_release_date;

        public Movie(String var_id, String var_vote, String var_title, String var_poster, String var_overview, String var_release_date) {
            this.var_id = var_id;
            this.var_vote = var_vote;
            this.var_title = var_title;
            this.var_poster = var_poster;
            this.var_overview = var_overview;
            this.var_release_date = var_release_date;
        }

        public String getVar_id() {
            return var_id;
        }

        public void setVar_id(String var_id) {
            this.var_id = var_id;
        }

        public String getVar_vote() {
            return var_vote;
        }

        public void setVar_vote(String var_vote) {
            this.var_vote = var_vote;
        }

        public String getVar_title() {
            return var_title;
        }

        public void setVar_title(String var_title) {
            this.var_title = var_title;
        }

        public String getVar_poster() {
            return var_poster;
        }

        public void setVar_poster(String var_poster) {
            this.var_poster = var_poster;
        }

        public String getVar_overview() {
            return var_overview;
        }

        public void setVar_overview(String var_overview) {
            this.var_overview = var_overview;
        }

        public String getVar_release_date() {
            return var_release_date;
        }

        public void setVar_release_date(String var_release_date) {
            this.var_release_date = var_release_date;
        }
    }




