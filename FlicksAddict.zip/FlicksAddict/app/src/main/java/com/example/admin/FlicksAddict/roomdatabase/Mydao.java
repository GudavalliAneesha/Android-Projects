package com.example.admin.FlicksAddict.roomdatabase;


import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;

import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface Mydao {
    @Insert
    void insert(Myentity myentity);
    @Delete
    void delete(Myentity myentity);
    @Query("select*from mytable")
    LiveData<List<Myentity>> livedata();
}
