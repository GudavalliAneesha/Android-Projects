package com.example.admin.FlicksAddict.roomdatabase;


import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class Viewmodel extends AndroidViewModel {
    public Myrepository myrepository;
    public LiveData<List<Myentity>> listLiveData;
    public Viewmodel(@NonNull Application application) {
        super(application);
        myrepository=new Myrepository(application);
        listLiveData=myrepository.livedata();

    }
    public void insert(Myentity myentity){
        myrepository.insert(myentity);

    }
    public LiveData<List<Myentity>> livedatalist(){
        return listLiveData;
    }
    public void delete(Myentity myentity){
        myrepository.delete(myentity);
    }
}
