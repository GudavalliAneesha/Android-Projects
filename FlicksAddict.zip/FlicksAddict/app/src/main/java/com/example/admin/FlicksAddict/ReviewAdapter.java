package com.example.admin.FlicksAddict;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.Holder> {
    Context ct;
    ArrayList<Review> arrayList1;
    public ReviewAdapter(ReviewActivity reviewActivity, ArrayList<Review> arrayList) {
        ct=reviewActivity;
        arrayList1=arrayList;
    }

    @Override
    public ReviewAdapter.Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(ct).inflate(R.layout.review,parent,false);

        return new Holder(v);

    }

    @Override
    public void onBindViewHolder(ReviewAdapter.Holder holder, int position) {
        holder.tv1.setText(arrayList1.get(position).getAuthor());
        holder.tv2.setText(arrayList1.get(position).getContent());

    }

    @Override
    public int getItemCount() {
        return arrayList1.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView tv1,tv2;
        public Holder(View itemView) {
            super(itemView);
            tv1=itemView.findViewById(R.id.author_id);
            tv2=itemView.findViewById(R.id.review_id);
        }
    }
}
