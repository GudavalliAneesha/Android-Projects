package com.example.admin.FlicksAddict;


import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyviewInfo> {
    MainActivity ct;
    ArrayList<Movie> mylist;
    public MyAdapter(MainActivity mainActivity, ArrayList<Movie> arrayList) {
        ct=mainActivity;
        mylist=arrayList;
    }

    @Override
    public MyAdapter.MyviewInfo onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(ct).inflate(R.layout.myresource,parent,false);
        return new MyviewInfo(view) ;

    }

    @Override
    public void onBindViewHolder(MyAdapter.MyviewInfo holder, int position) {
        Picasso.with(ct).load(mylist.get(position).getVar_poster()).into(holder.iv);

    }

    @Override
    public int getItemCount() {

        return mylist.size();
    }

    public class MyviewInfo extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView iv;
        public MyviewInfo(View itemView) {
            super(itemView);
            iv=itemView.findViewById(R.id.image_id);
            iv.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();
            Intent intent=new Intent(ct,DetailsActivity.class);
            intent.putExtra("image",mylist.get(position).getVar_poster());
            intent.putExtra("tit",mylist.get(position).getVar_title());
            intent.putExtra("rate",mylist.get(position).getVar_vote());
            intent.putExtra("rel",mylist.get(position).getVar_release_date());
            intent.putExtra("over",mylist.get(position).getVar_overview());
            intent.putExtra("key",mylist.get(position).getVar_id());

            ct.startActivity(intent);

        }
    }
}
