package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        List<String>alsoknow=new ArrayList<>();
        List<String>ingredients=new ArrayList<>();
        Sandwich sandwich=new Sandwich();
        try {
            JSONObject object=new JSONObject(json);
            JSONObject item_name=object.getJSONObject("name");
            String main_item=item_name.getString("mainName");
            String image=object.getString("image");
            JSONArray also_know=item_name.getJSONArray("alsoKnownAs");
            if(also_know.length()==0){
                alsoknow.add("data not found");
            }
            else{
                for(int i=0;i<also_know.length();i++){
                    alsoknow.add(also_know.getString(i));

                }
            }
            JSONArray ingr=object.getJSONArray("ingredients");
            if(ingr!=null){
                for(int i=0;i<ingr.length();i++){
                    ingredients.add(ingr.getString(i));
                }
            }
            String description =object.getString("description");
            String place=object.getString("placeOfOrigin");
            String place_origin="";
            if(place.isEmpty()){
                place_origin="no data found";

            }
            else{
                place_origin=place;




            }
            sandwich.setMainName(main_item);
            sandwich.setAlsoKnownAs(alsoknow);
            sandwich.setPlaceOfOrigin(place_origin);
            sandwich.setDescription(description);
            sandwich.setImage(image);
            sandwich.setIngredients(ingredients);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return sandwich;
    }
}
